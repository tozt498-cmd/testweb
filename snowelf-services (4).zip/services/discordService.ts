import { OrderData } from '../types';
import { DISCORD_WEBHOOK_URL } from '../constants';

export const sendOrderToDiscord = async (order: OrderData): Promise<boolean> => {
  if (!DISCORD_WEBHOOK_URL) {
    console.error("Webhook URL is missing");
    return false;
  }

  // Format "Système" propre et sans emoji
  const embed = {
    title: "Nouvelle Transaction",
    color: 0x5E17EB, // Violet SnowELF (Brand Color)
    fields: [
      {
        name: "Identifiant Client",
        value: `\`${order.discordUser}\``, // Bloc de code pour le style technique
        inline: true
      },
      {
        name: "Email de facturation",
        value: `\`${order.email}\``,
        inline: true
      },
      {
        name: "Service",
        value: `**${order.product.title}**`,
        inline: false
      },
      {
        name: "Montant",
        value: `${order.product.price} EUR`,
        inline: true
      },
      {
        name: "Statut",
        value: "En attente de paiement",
        inline: true
      },
      {
        name: "Cahier des charges",
        value: `>>> ${order.projectDescription || "Aucune description fournie."}`, // Citation pour le texte long
        inline: false
      }
    ],
    footer: {
      text: "SnowELF Order System • ID: " + Date.now().toString().slice(-8), // Faux ID de transaction pour faire pro
    },
    timestamp: new Date().toISOString()
  };

  try {
    const response = await fetch(DISCORD_WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username: "SnowELF | Transactions",
        embeds: [embed],
      }),
    });

    return response.ok;
  } catch (error) {
    console.error("Error sending webhook:", error);
    return false;
  }
};