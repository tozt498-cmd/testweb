import React, { useRef, useState } from 'react';
import { ArrowRight, Check, Sparkles, Box, Layout, Zap } from 'lucide-react';
import { Product, Category } from '../types';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  index: number;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect, index }) => {
  const divRef = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [opacity, setOpacity] = useState(0);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!divRef.current) return;

    const div = divRef.current;
    const rect = div.getBoundingClientRect();

    setPosition({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  const handleMouseEnter = () => {
    setOpacity(1);
  };

  const handleMouseLeave = () => {
    setOpacity(0);
  };

  const getIcon = () => {
      if(product.category === Category.DISCORD) return <Box className="text-blue-400 group-hover:text-blue-300 transition-colors" size={28} />;
      return <Layout className="text-emerald-400 group-hover:text-emerald-300 transition-colors" size={28} />;
  }

  return (
    <div
      ref={divRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={() => onSelect(product)}
      className={`relative h-full w-full rounded-3xl overflow-hidden cursor-pointer group border border-white/10 bg-[#0A0A0A] transition-transform duration-300 hover:scale-[1.02] hover:-translate-y-1 animate-fade-in-up`}
      style={{
        animationDelay: `${index * 150}ms`, // Délai progressif pour chaque carte
        opacity: 0, 
        animationFillMode: 'forwards'
      }}
    >
      {/* 1. Spotlight Effect Gradient (Lueur de fond qui suit la souris) */}
      <div
        className="pointer-events-none absolute -inset-px opacity-0 transition-opacity duration-300"
        style={{
          opacity,
          background: `radial-gradient(600px circle at ${position.x}px ${position.y}px, rgba(255,255,255,0.06), transparent 40%)`,
        }}
      />
      
      {/* 2. Border Glow via spotlight (Bordure qui s'illumine sous la souris) */}
      <div
        className="pointer-events-none absolute -inset-px rounded-3xl opacity-0 transition-opacity duration-300"
        style={{
          opacity,
          background: `radial-gradient(600px circle at ${position.x}px ${position.y}px, rgba(255,255,255,0.3), transparent 40%)`,
          maskImage: 'linear-gradient(black, black) content-box, linear-gradient(black, black)',
          maskComposite: 'exclude',
          WebkitMaskComposite: 'xor',
          padding: '1px'
        }}
      />

      <div className="relative h-full flex flex-col p-8 z-10">
        
        {/* Header: Icon & Badge */}
        <div className="flex justify-between items-start mb-6">
            <div className="p-3 rounded-2xl bg-white/5 border border-white/5 shadow-inner group-hover:bg-white/10 transition-colors duration-500">
                {getIcon()}
            </div>
            {product.popular && (
                <span className="relative inline-flex overflow-hidden rounded-full p-[1px]">
                  <span className="absolute inset-[-1000%] animate-[spin_2s_linear_infinite] bg-[conic-gradient(from_90deg_at_50%_50%,#E2CBFF_0%,#393BB2_50%,#E2CBFF_100%)]" />
                  <span className="inline-flex h-full w-full cursor-pointer items-center justify-center rounded-full bg-slate-950/90 px-3 py-1 text-xs font-medium text-white backdrop-blur-3xl">
                    <Sparkles size={12} className="mr-1 text-purple-400" /> Populaire
                  </span>
                </span>
            )}
        </div>

        {/* Title & Desc */}
        <h3 className="text-2xl font-display font-bold text-white mb-3 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-gray-400 transition-all">
            {product.title}
        </h3>
        
        <p className="text-gray-400 text-sm leading-relaxed mb-8 flex-grow group-hover:text-gray-300 transition-colors">
            {product.description}
        </p>

        {/* Features List */}
        <ul className="space-y-4 mb-8">
            {product.features.slice(0, 4).map((feat, i) => (
                <li key={i} className="flex items-center gap-3 text-sm text-gray-500 group-hover:text-gray-300 transition-colors duration-300">
                    <div className="flex-shrink-0 w-5 h-5 rounded-full bg-white/5 flex items-center justify-center border border-white/5 group-hover:border-green-500/30 group-hover:bg-green-500/10 transition-colors">
                         <Check size={10} className="text-gray-600 group-hover:text-green-400 transition-colors" />
                    </div>
                    {feat}
                </li>
            ))}
        </ul>

        {/* Action Area (Price & Animated Button) */}
        <div className="mt-auto pt-6 border-t border-white/5 flex items-center justify-between">
            <div className="flex flex-col">
                <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest">Tarif unique</span>
                <span className="text-3xl font-display font-bold text-white tracking-tight">{product.price}€</span>
            </div>
            
            {/* Le bouton s'étend au survol */}
            <button className="relative group/btn w-12 h-12 rounded-full bg-white text-black flex items-center justify-center overflow-hidden transition-all duration-300 hover:w-32 hover:bg-white hover:scale-105 shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_20px_rgba(255,255,255,0.4)]">
                <div className="absolute flex items-center justify-center w-full h-full transition-all duration-300 group-hover/btn:opacity-0 group-hover/btn:-translate-x-full">
                   <ArrowRight size={20} />
                </div>
                <div className="absolute flex items-center justify-center w-full h-full opacity-0 translate-x-full transition-all duration-300 group-hover/btn:opacity-100 group-hover/btn:translate-x-0 font-bold text-sm">
                   Choisir
                </div>
            </button>
        </div>
        
        {/* Subtle Background Pattern (Noise) */}
         <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-soft-light pointer-events-none"></div>
      </div>
    </div>
  );
};

export default ProductCard;