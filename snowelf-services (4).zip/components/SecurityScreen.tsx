import React, { useEffect, useState } from 'react';
import { Shield, Lock, Globe, Server, CheckCircle, Activity, Wifi } from 'lucide-react';

interface SecurityScreenProps {
  onVerified: () => void;
}

const SecurityScreen: React.FC<SecurityScreenProps> = ({ onVerified }) => {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState("Initialisation du SnowELF Shield...");
  const [rayId, setRayId] = useState("");
  const [isFadingOut, setIsFadingOut] = useState(false);

  useEffect(() => {
    // Generate a fake Ray ID like Cloudflare
    const generateRayId = () => {
        const chars = '0123456789ABCDEF';
        let result = '';
        for (let i = 0; i < 16; i++) {
            result += chars[Math.floor(Math.random() * chars.length)];
        }
        setRayId(result);
    };
    generateRayId();

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setStatusText("Accès autorisé. Redirection...");
          setTimeout(() => {
            setIsFadingOut(true);
            setTimeout(onVerified, 800);
          }, 500);
          return 100;
        }
        return prev + Math.random() * 8; // Slower progress for realism
      });
    }, 200);

    return () => clearInterval(timer);
  }, [onVerified]);

  useEffect(() => {
      if(progress > 20 && progress < 40) setStatusText("Analyse de l'intégrité du navigateur...");
      if(progress > 40 && progress < 70) setStatusText("Vérification anti-bot & DDoS...");
      if(progress > 70 && progress < 90) setStatusText("Établissement du tunnel sécurisé TLS...");
  }, [progress]);

  return (
    <div className={`fixed inset-0 z-[100] bg-[#000000] flex flex-col items-center justify-center p-6 transition-opacity duration-700 ${isFadingOut ? 'opacity-0' : 'opacity-100'}`}>
      
      {/* Background Matrix/Grid Effect */}
      <div className="absolute inset-0 overflow-hidden opacity-10 pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#00F0FF1a_1px,transparent_1px),linear-gradient(to_bottom,#00F0FF1a_1px,transparent_1px)] bg-[size:2rem_2rem]" />
      </div>

      <div className="max-w-xl w-full bg-[#050505] border border-white/5 rounded-none p-0 relative overflow-hidden shadow-2xl font-mono">
        {/* Top Bar Decoration */}
        <div className="h-1 w-full bg-gradient-to-r from-blue-600 via-purple-600 to-blue-600 animate-shimmer bg-[length:200%_100%]"></div>
        
        <div className="p-8 md:p-10 flex flex-col items-start relative z-10">
            
            <div className="flex items-center gap-4 mb-8 w-full">
                <div className="relative">
                    <div className="absolute inset-0 bg-blue-500/20 rounded-full animate-ping"></div>
                    <div className="relative z-10 p-3 bg-blue-900/20 rounded-full border border-blue-500/50 text-blue-400">
                        {progress < 100 ? <Activity className="animate-pulse" size={32} /> : <CheckCircle size={32} className="text-green-500" />}
                    </div>
                </div>
                <div>
                    <h1 className="text-2xl font-bold text-white tracking-tight">SnowELF<span className="text-blue-500">Guard</span></h1>
                    <p className="text-gray-500 text-xs uppercase tracking-widest mt-1">DDoS Mitigation Layer</p>
                </div>
            </div>

            <div className="space-y-4 w-full mb-8">
                <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Statut de la connexion</span>
                    <span className="text-white flex items-center gap-2">
                        {progress < 100 ? (
                            <>
                                <span className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></span>
                                Vérification...
                            </>
                        ) : (
                            <>
                                <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                                Sécurisé
                            </>
                        )}
                    </span>
                </div>
                
                {/* Progress Bar styled like a terminal loader */}
                <div className="w-full h-2 bg-gray-900 rounded-sm overflow-hidden border border-white/10">
                    <div 
                        className="h-full bg-blue-500 shadow-[0_0_10px_#3b82f6]"
                        style={{ width: `${Math.min(progress, 100)}%`, transition: 'width 0.2s ease-out' }}
                    />
                </div>
                
                <p className="text-xs text-gray-500 h-4">{statusText}</p>
            </div>

            {/* Technical Details Grid */}
            <div className="grid grid-cols-2 gap-4 w-full border-t border-white/5 pt-6 mt-2">
                <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-gray-600 uppercase">Ray ID</span>
                    <span className="text-xs text-gray-300 font-mono">{rayId}</span>
                </div>
                <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-gray-600 uppercase">IP Client</span>
                    <span className="text-xs text-gray-300 font-mono flex items-center gap-1">
                         <Globe size={10} /> Masquée (Cryptée)
                    </span>
                </div>
                <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-gray-600 uppercase">Serveur</span>
                    <span className="text-xs text-gray-300 font-mono flex items-center gap-1">
                        <Server size={10} /> Paris (CDG-01)
                    </span>
                </div>
                <div className="flex flex-col gap-1">
                    <span className="text-[10px] text-gray-600 uppercase">Protocole</span>
                    <span className="text-xs text-gray-300 font-mono flex items-center gap-1">
                        <Lock size={10} /> TLS 1.3 / H2
                    </span>
                </div>
            </div>

        </div>
      </div>

      <div className="absolute bottom-8 text-center opacity-50">
        <p className="text-gray-600 text-[10px] font-mono flex items-center justify-center gap-2">
            <Shield size={12} />
            Performance & Security by SnowELF Network
        </p>
      </div>
    </div>
  );
};

export default SecurityScreen;