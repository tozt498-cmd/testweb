import React, { useState } from 'react';
import { X, AlertCircle, ShoppingBag, ShieldCheck } from 'lucide-react';
import { Product } from '../types';
import Button from './Button';
import { sendOrderToDiscord } from '../services/discordService';
import { PAYPAL_EMAIL } from '../constants';

interface OrderModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

const OrderModal: React.FC<OrderModalProps> = ({ product, isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    discordUser: '',
    email: '',
    description: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !product) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    const success = await sendOrderToDiscord({
      discordUser: formData.discordUser,
      email: formData.email,
      projectDescription: formData.description,
      product: product,
    });

    if (success) {
      const paypalUrl = `https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=${PAYPAL_EMAIL}&currency_code=EUR&amount=${product.price}&item_name=${encodeURIComponent(product.title + " - " + formData.discordUser)}&return=https://github.com`;
      window.open(paypalUrl, '_blank');
      onClose();
    } else {
      setError("Une erreur est survenue lors de la communication avec le serveur.");
    }

    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-xl transition-opacity duration-300"
        onClick={onClose}
      />

      <div className="relative w-full max-w-lg bg-[#050505] border border-white/10 rounded-3xl shadow-2xl overflow-hidden animate-fade-in-up">
        {/* Decorative Top Gradient */}
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent opacity-50"></div>
        
        <div className="p-8 relative z-10">
            {/* Header */}
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h2 className="text-2xl font-bold text-white tracking-tight">Finaliser la commande</h2>
                    <p className="text-gray-500 text-sm mt-1 flex items-center gap-2">
                        <ShieldCheck size={14} className="text-accent" /> Paiement sécurisé via PayPal
                    </p>
                </div>
                <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors p-2 hover:bg-white/10 rounded-full">
                    <X size={20} />
                </button>
            </div>
            
            {/* Product Summary */}
            <div className="bg-white/5 rounded-2xl p-4 mb-8 flex items-center gap-4 border border-white/5 ring-1 ring-white/5">
                <div className="w-12 h-12 bg-gradient-to-br from-gray-800 to-black rounded-xl flex items-center justify-center text-white border border-white/10 shadow-lg">
                    <ShoppingBag size={20} />
                </div>
                <div>
                    <h3 className="text-white font-bold">{product.title}</h3>
                    <div className="flex items-center gap-2">
                         <span className="text-primary font-bold">{product.price}€</span>
                         <span className="text-xs text-gray-500 uppercase">/ unique</span>
                    </div>
                </div>
            </div>

            {/* Form */}
            <form onSubmit={handleOrder} className="space-y-6">
                <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Identifiant Discord</label>
                    <input 
                        type="text" 
                        name="discordUser"
                        required 
                        value={formData.discordUser} 
                        onChange={handleChange} 
                        className="w-full bg-black border border-white/10 rounded-xl p-4 text-white text-sm focus:border-primary/50 focus:ring-1 focus:ring-primary/50 outline-none transition-all placeholder:text-gray-700" 
                        placeholder="Pseudo#0000" 
                    />
                </div>
                
                <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Email PayPal</label>
                    <input 
                        type="email" 
                        name="email"
                        required 
                        value={formData.email} 
                        onChange={handleChange} 
                        className="w-full bg-black border border-white/10 rounded-xl p-4 text-white text-sm focus:border-primary/50 focus:ring-1 focus:ring-primary/50 outline-none transition-all placeholder:text-gray-700" 
                        placeholder="votre@email.com" 
                    />
                </div>

                <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Détails du Projet</label>
                    <textarea 
                        name="description"
                        required 
                        rows={3} 
                        value={formData.description} 
                        onChange={handleChange} 
                        className="w-full bg-black border border-white/10 rounded-xl p-4 text-white text-sm focus:border-primary/50 focus:ring-1 focus:ring-primary/50 outline-none transition-all resize-none placeholder:text-gray-700" 
                        placeholder="Décrivez brièvement vos besoins..." 
                    />
                </div>

                {error && (
                  <div className="text-red-400 text-xs flex items-center gap-2 bg-red-900/10 border border-red-900/30 p-4 rounded-xl">
                    <AlertCircle size={16} />
                    {error}
                  </div>
                )}

                <Button type="submit" fullWidth isLoading={isSubmitting} className="mt-2">
                    Passer au paiement
                </Button>
            </form>
        </div>
      </div>
    </div>
  );
};

export default OrderModal;