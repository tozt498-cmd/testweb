import React, { useState, useEffect } from 'react';
import { Users, Activity, Zap, ShieldCheck } from 'lucide-react';

const AnimatedCounter = ({ end, duration = 2000 }: { end: number, duration?: number }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    // Si le nombre est petit (ex: 4), on ralentit l'incrémentation pour que l'animation se voie
    const endFloat = parseFloat(end.toString());
    const step = endFloat > 20 ? endFloat / (duration / 16) : 0.1; 

    const timer = setInterval(() => {
      start += step;
      if (start >= endFloat) {
        start = endFloat;
        clearInterval(timer);
      }
      setCount(Math.floor(start));
    }, endFloat > 20 ? 16 : 100); // Vitesse adaptée aux petits nombres

    return () => clearInterval(timer);
  }, [end, duration]);

  return <span>{count.toLocaleString()}</span>;
};

const StatsSection: React.FC = () => {
  const [dataPoints, setDataPoints] = useState<number[]>([]);

  useEffect(() => {
    const initialData = Array.from({ length: 30 }, () => 20 + Math.random() * 30);
    setDataPoints(initialData);

    const interval = setInterval(() => {
      setDataPoints(prev => {
        const newData = [...prev.slice(1), 20 + Math.random() * 40];
        return newData;
      });
    }, 100); 

    return () => clearInterval(interval);
  }, []);

  const getPolylinePoints = () => {
    if (dataPoints.length === 0) return "";
    const width = 100;
    const stepX = width / (dataPoints.length - 1);
    return dataPoints.map((val, i) => `${i * stepX},${100 - val}`).join(" ");
  };

  return (
    <div className="w-full py-32 relative">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Header Section */}
        <div className="mb-16 text-center animate-fade-in-up">
            <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-4">
                Transparence <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-primary">Totale</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
                Nos métriques sont publiques. La qualité prime sur la quantité.
            </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Card 1: Live Traffic (Big) */}
            <div className="lg:col-span-2 bg-white/[0.02] backdrop-blur-xl border border-white/10 rounded-3xl p-8 relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                
                <div className="flex justify-between items-start mb-8 relative z-10">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary border border-primary/20 shadow-[0_0_15px_rgba(94,23,235,0.3)]">
                            <Activity size={20} />
                        </div>
                        <div>
                            <h3 className="text-white font-bold">Protection Réseau</h3>
                            <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                                <span className="text-xs text-green-400 font-mono">MITIGATION ACTIVE</span>
                            </div>
                        </div>
                    </div>
                    <div className="text-right">
                         <div className="text-3xl font-display font-bold text-white tracking-tighter">
                            <AnimatedCounter end={18942} duration={3000} />
                         </div>
                         <p className="text-xs text-gray-500 uppercase tracking-widest">Paquets / min</p>
                    </div>
                </div>

                {/* Graphique Ultra Modern */}
                <div className="h-[250px] w-full relative">
                    <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 100 100">
                        <defs>
                            <linearGradient id="glowGradient" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="#00F0FF" stopOpacity="0.3" />
                                <stop offset="100%" stopColor="#00F0FF" stopOpacity="0" />
                            </linearGradient>
                            <filter id="neonGlow" x="-50%" y="-50%" width="200%" height="200%">
                                <feGaussianBlur stdDeviation="2" result="coloredBlur" />
                                <feMerge>
                                    <feMergeNode in="coloredBlur" />
                                    <feMergeNode in="SourceGraphic" />
                                </feMerge>
                            </filter>
                        </defs>
                        <path 
                            d={`M0,100 L${getPolylinePoints()} L100,100 Z`} 
                            fill="url(#glowGradient)" 
                        />
                        <polyline 
                            points={getPolylinePoints()} 
                            fill="none" 
                            stroke="#00F0FF" 
                            strokeWidth="1.5"
                            filter="url(#neonGlow)"
                            vectorEffect="non-scaling-stroke"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="transition-all duration-100 ease-linear"
                        />
                    </svg>
                    
                    {/* Grid Overlay */}
                    <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none"></div>
                </div>
            </div>

            {/* Card 2: Stats Verticales */}
            <div className="space-y-6">
                
                {/* Stat Box 1 */}
                <div className="bg-white/[0.02] backdrop-blur-xl border border-white/10 rounded-3xl p-6 relative overflow-hidden group hover:border-accent/30 transition-colors h-[48%] flex flex-col justify-center">
                    <div className="flex items-center gap-4">
                        <div className="p-3 rounded-xl bg-accent/10 text-accent border border-accent/20">
                            <ShieldCheck size={24} />
                        </div>
                        <div>
                            <p className="text-gray-400 text-xs uppercase tracking-widest">Sécurité</p>
                            <p className="text-2xl font-bold text-white">Shield v4.2</p>
                        </div>
                    </div>
                </div>

                {/* Stat Box 2 */}
                <div className="bg-white/[0.02] backdrop-blur-xl border border-white/10 rounded-3xl p-6 relative overflow-hidden group hover:border-purple-500/30 transition-colors h-[48%] flex flex-col justify-center">
                     <div className="flex items-center gap-4">
                        <div className="p-3 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                            <Users size={24} />
                        </div>
                        <div>
                            <p className="text-gray-400 text-xs uppercase tracking-widest">Clients</p>
                            <p className="text-2xl font-bold text-white">
                                <AnimatedCounter end={4} duration={1000} />
                            </p>
                        </div>
                    </div>
                </div>

            </div>

        </div>
      </div>
    </div>
  );
};

export default StatsSection;